#!/bin/sh
echo "Xiaomi Hacks enabled"

/mnt/sdcard/manu_test/disable_factory_mode.sh
/mnt/sdcard/manu_test/configure_services.sh &
