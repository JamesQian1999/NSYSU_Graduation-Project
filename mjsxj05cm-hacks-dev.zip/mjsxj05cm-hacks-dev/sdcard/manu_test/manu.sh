#!/bin/sh
/mnt/sdcard/manu_test/entrypoint.sh